﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{ 

  class Sphere
  {

  private double radius;

  public Sphere()
  {
    radius = 0;

  }

  public void setRadius(double value)
  {
    radius = value;
  }




  public double getVolume()
  {
    return 4.0 / 3.0 * 3.1415 * radius * radius * radius;
  }

  public double getSurfaceArea()
  {
    double area;


    area = 4 * 3.1415 * radius * radius;

    return area;
  }

}
}
