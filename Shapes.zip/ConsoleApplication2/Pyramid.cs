﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{ 
 class Pyramid
{
  private double length;
  private double width;
  private double height;


  public Pyramid()
  {
    length = 0;
    width = 0;
    height = 0;
  }

  public void setLength(double value)
  {
    length = value;
  }
  public void setWidth(double value)
  {
    width = value;
  }
  public void setHeight(double value)
  {
    height = value;
  }



  public double getVolume()
  {
    double b;

    b = length * width;
    return (1.0 / 3.0) * b * height;
  }

  public double getSurfaceArea()
  {
    double L2;
    double W2;
    double r;
    double L;
    double bA;
    double p;
    double product;
    double area;

    L2 = length / 2.0;
    W2 = width / 2.0;
    p = (2 * length) + (2 * width);
    r = Math.Sqrt( p * (L2 * L2) + (W2 * W2));
    L = Math.Sqrt((height * height) + (r + r));
    bA = length * width; 
    product = (p * L) / 2;

    area = bA * product;

    return area;
  }

}
}