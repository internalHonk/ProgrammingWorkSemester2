﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
  class box
  {
    private double length;
    private double width;
    private double height;

    public box()
    {
      length = 0;
      width = 0;
      height = 0;
    }

    public void setLength(double value)
    {
      length = value;
    }
    public void setWidth(double value)
    {
      width = value;
    }
    public void setHeight(double value)
    {
      height = value;
    }



    public double getVolume()
    {
      return length * width * height;
    }

    public double getSurfaceArea()
    {
      double frontBack;
      double sides;
      double topBottom;
      double area;

      frontBack = width * height * 2;
      sides = length * height * 2;
      topBottom = length * width * 2;

      area = frontBack + sides + topBottom;

      return area;
    }

  }
}
