﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
  class shapes
  {
    static void CalculateBox()
    {
      box b1 = new box();

      double length;
      double width;
      double height;

      String input;

      Console.WriteLine("Enter the following dimensions:");

      Console.Write("Length :");
      input = Console.ReadLine();
      length = double.Parse(input);
      b1.setLength(length);


      Console.Write("Width  :");
      input = Console.ReadLine();
      width = double.Parse(input);
      b1.setWidth(width);

      Console.Write("Height :");
      input = Console.ReadLine();
      height = double.Parse(input);
      b1.setHeight(height);

      Console.WriteLine("volume of box: {0}", b1.getVolume());

      Console.WriteLine("surface area of box: {0}", b1.getSurfaceArea());
    }

    static void CalculateSphere()
    {
      Sphere s1 = new Sphere();
      double radius;

      String input;

      Console.WriteLine("Enter the following dimensions:");

      Console.Write("Radius:");
      input = Console.ReadLine();
      radius = double.Parse(input);
      s1.setRadius(radius);

      Console.WriteLine("volume of sphere: {0}", s1.getVolume());

      Console.WriteLine("surface area of sphere: {0}", s1.getSurfaceArea());
    }

    static void CalculatePyramid()
    {
      Pyramid v1 = new Pyramid();

      double length;
      double width;
      double height;

      String input;

      Console.WriteLine("Enter the following dimensions:");

      Console.Write("Length :");
      input = Console.ReadLine();
      length = double.Parse(input);
      v1.setLength(length);

      Console.Write("Width  :");
      input = Console.ReadLine();
      width = double.Parse(input);
      v1.setWidth(width);

      Console.Write("Height :");
      input = Console.ReadLine();
      height = double.Parse(input);
      v1.setHeight(height);

      Console.WriteLine("volume of pyramid: {0}", v1.getVolume());

      Console.WriteLine("surface area of pyramid: {0}", v1.getSurfaceArea());
    }



    static void Main(string[] args)
    {
      Console.WriteLine("Welcome to shapes:");

      char choice;

      do
      {
        Console.WriteLine("Choose an option:");
        Console.WriteLine("  b - box");
        Console.WriteLine("  p - pyramid");
        Console.WriteLine("  s - sphere");
        Console.WriteLine("  q - quit");
        Console.WriteLine("");

        String input = Console.ReadLine();

        choice = char.Parse(input);

        if ('b' == choice)
        {
          CalculateBox();
        }
        else if ('p' == choice)
        {
          CalculatePyramid();
        }
        else if ('s' == choice)
        {
          CalculateSphere();
        }

        Console.WriteLine("");
      }
      while (choice != 'q');


      Console.WriteLine("");
      Console.WriteLine("Goodbye!");
    }
  }
}
 